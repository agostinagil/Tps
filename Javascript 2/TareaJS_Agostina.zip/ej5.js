function fibolacci (num){
    let a=0, b=1, c, s=1;
    console.log(a,b);
    for(i=0; i<=num; i++){
        
    }
}