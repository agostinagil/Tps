let Agostina = {
    nombreCompleto: `Agostina Yael Gil`,
    edad: `23 años`,
    nacionalidad: `Argentina`,
    ciudadNatal: `Córdoba Capital`,
    vivoEn: `Buenos Aires`,
    familia:[
        {nombre: `Vanesa`, apellido:`Martinez`, vínculo:`madre`, edad: `45 años`},
        {nombre: `Diego`, apellido: `Gil`, vínculo: `padre`, edad: `44 años`},
        {nombre: `Tomás`, apellido: `Gil`, vínculo: `hermano`, edad: `19 años`},
        {nombre: `Florencia`, apellido: `Gil`, vínculo: `hermana`, edad: `17 años`},
    ],
    mascotas: [
       {nombre: `Kaira` , animal: `Perro`, raza: `Pichichu`, edad: `1 año`, estado: `vivita y coleando`},
       {nombre: `Brisa`, animal: `Perro`, raza: `Bichón Frisé` , edad: `8 años`, estado: `vivita y coleando`},
       {nombre: `Luna`, animal: `Perro` , raza: `Bichón Frisé`, edad: `no se, ya está viejita, creo que 10 años`, estado: `ya le cuesta respirar... nah mentira, está más jóven que las otras dos`},
       {nombre: `Acá iría mi conejito que me regalaron a los 7 años, pero no tengo suficientes recuerdos ya que me duró una semana... mi hermano decidió cepillarle los dientes y lo asfixió. R.I.P`},
    ],
    estudios: [
        {nivel: `Secundario`, estado: `Graduada`, título: `Bachiller en Comunicación`},
        {nivel:`Universitario`, estado: `Abandonadísimo`, título:`ex futura abogada`},
    ],
    cursos: [
        {nombre: `Introducción a la fotografía digital`, estado: `finalizado`, año: 2018},
        {nombre:`Fotografía de moda` , estado: `finalizado`, año: 2018},
        {nombre: `Programación Web Inicial`, estado: `en curso`,  año: 2020},
    ],
    musica: [
        {genero: `Rock`, bandas: `Pink Floyd, Led Zeppelin, Queen, Aerosmith, Guns N' Roses, Red Hot Chili Peppers, Radiohead`},
        {genero: `Electrónica (sin entrar en subgeneros)`, djs: `Tale Of Us, Maceo Plex, Colyn, Mathame, Fideles, Artbat, Boris Brejcha, Joris Voorn, Adriatique, Agents Of Time, Eric Prydz, Innellea, Deborah de Luca, Amelie Lens, Nina Kraviz , etc los amo a todos`}
    ]

}